
from PIL import Image
import numpy as np
import cv2
import matplotlib.pyplot as plt # plt show image
import matplotlib.image as mpimg # mpimg read image
import skimage
import sys
from skimage import io,data, color,draw,transform,feature,util

def image2array(imagepath):
    #imagepath = "SAJB_90_shear_S2_02267_00553.tif"
    im2 = mpimg.imread(imagepath)
    
    img = Image.open(imagepath)
    R = im2[: ,: ,0]
    G = im2[: ,: ,1]
    B = im2[: ,: ,2]
    A = im2[: ,: ,3]
    # plt.imshow(lum_img,cmap = 'nipy_spectral')
    # plt.plot(736.029, 1461.87, 'ro')
    # plt.colorbar()
    return R, G, B, A, img

def transform_gray(input_path):
    img1 = cv2.imread(input_path)
    print(img1)
    gray = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    return gray

def radius(a, b, center_x, center_y):
    return np.sqrt((a - center_x) ** 2 + (b - center_y) ** 2) 

def find_center(): # the algorithm is the same as in "circle_find.py"
    image_path = 'c:/Users/xiyuq/Desktop/project/project_summer/meeting_6_25/meeting7_9_16/sax.png'
    im2 = mpimg.imread(image_path)
    image = im2[:,:,0]
    edges =feature.canny(image) 
    fig, (ax0,ax1) = plt.subplots(1,2, figsize=(18, 15))
    ax0.imshow(edges, cmap=plt.cm.gray) 
    ax0.set_title('original iamge')
    
    hough_radii = np.arange(10, 14, 1) 

    hough_res =transform.hough_circle(edges, hough_radii) 

    centers = [] 
    accums = [] 
    radii = [] 
    for radius, h in zip(hough_radii, hough_res):
        num_peaks = 20
        peaks =feature.peak_local_max(h, num_peaks=num_peaks) 
        centers.extend(peaks)
        accums.extend(h[peaks[:, 0], peaks[:, 1]])
        radii.extend([radius] * num_peaks)

    image = color.gray2rgb(image)
    for idx in np.argsort(accums)[::-1][:8]:
        center_x, center_y = centers[idx]
        radius = radii[idx]
        cx, cy =draw.circle_perimeter(center_y, center_x, radius)
        print(center_y,center_x,radius)
        image[cy,cx] = (250,0,0)

    ax1.imshow(image)
    plt.show()
    return center_y,center_x

def main():

    imagepath = 'c:/Users/xiyuq/Desktop/project/project_summer/meeting_6_25/meeting7_9_16/sax.png'
    gray = transform_gray(imagepath)
    width, height = gray.shape[0], gray.shape[1]
    center_y,center_x = find_center()
    R, G, B, A, img = image2array(imagepath)
    plt.imshow(img)
    plt.show()

    for i in range(width):
        for j in range(height):
            caculate_radius = radius(i, j, center_x, center_y)
            if caculate_radius >= 100:
                gray[i][j] = 0
    plt.imshow(gray)
    cv2.imwrite('c:/Users/xiyuq/Desktop/project/project_summer/meeting_6_25/meeting7_9_16/black.png',gray)
    plt.show()

if __name__ == "__main__":
    main()