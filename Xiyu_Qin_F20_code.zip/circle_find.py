from PIL import Image
import numpy as np
import cv2
import matplotlib.pyplot as plt # plt show image
import matplotlib.image as mpimg # mpimg read image
import sys
import skimage
from skimage import data, color,draw,transform,feature,util,io
# this py file is to use to find the cirlce 


# (1) finding circle section
image_path = 'c:/Users/xiyuq/Desktop/project/project_summer/meeting_6_25/meeting7_9_16/SAJB_90_shear_S2_02267_00553.tif'
im2 = mpimg.imread(image_path)  #read the image
image = im2[:,:,0].T   #extract array 
edges =feature.canny(image, sigma=1, low_threshold=10, high_threshold=50) #detect the edge of image 
#plt.imshow(edges) #you can see how the edge like in this line
fig, (ax0,ax1,ax2,ax3) = plt.subplots(1,4, figsize=(18, 15))  #create the plot 
ax0.imshow(edges, cmap=plt.cm.gray) #first image, show the edge of image
ax0.set_title('original iamge')
 
hough_radii = np.arange(20, 200, 2) # define the range of the circle radius

hough_res =transform.hough_circle(edges, hough_radii) # hough circle transform 

centers = [] #sav the middle coordinate
accums = [] # accummulate value
radii = [] #radius

for radius, h in zip(hough_radii, hough_res):
 num_peaks = 9 # every value of radius, extract 9 circle on that
 peaks =feature.peak_local_max(h, num_peaks=num_peaks) # get the peak value
 centers.extend(peaks)
 accums.extend(h[peaks[:, 0], peaks[:, 1]])
 radii.extend([radius] * num_peaks)

# draw the circle
image = color.gray2rgb(image)
for idx in np.argsort(accums)[::-1][:1]:  #[:1] can define how many circle do you want to draw
 center_x, center_y = centers[idx]
 radius = radii[idx]
 cx, cy =draw.circle_perimeter(center_y, center_x, radius)
 print(center_y,center_x,radius)
 image[cy,cx] = (250,0,0)
ax1.imshow(image)
cv2.imwrite('c:/Users/xiyuq/Desktop/project/project_summer/meeting_6_25/meeting7_9_16/detected.png',image) #save the image
ax1.set_title('detected image')
cropped = image[0:,0:center_y]
ax2.set_title('left cropped')
ax2.imshow(cropped)

# (2) mirror and combine section
mirror = cv2.flip(cropped,1)#transform.rotate(cropped,180)
mirror2 = transform.rotate(cropped,0)
mirror3 = transform.rotate(mirror,0)
ax3.set_title('right cropped')
ax3.imshow(mirror)
plt.show()
imgInfo = mirror.shape
height= imgInfo[0]
width = imgInfo[1]
deep = imgInfo[2]

dst = np.zeros([height, width*2, deep])
dst[0:height,0:width] = mirror2
dst[0:height,width:] = mirror3
plt.imshow(dst)
dst = dst * 255
cv2.imwrite('c:/Users/xiyuq/Desktop/project/project_summer/meeting_6_25/meeting7_9_16/combine.png',dst)
plt.show()

# (3) find the circle for combined circle, same algorithm in section(1)
big_image = dst
edges2 =feature.canny(big_image[:,:,0], sigma=1, low_threshold=10, high_threshold=50)
fig, (ax0,ax1) = plt.subplots(1,2, figsize=(18, 15))
ax0.imshow(edges2, cmap=plt.cm.gray) 
ax0.set_title('original iamge')
hough_radii = np.arange(100, 400, 2) 
hough_res =transform.hough_circle(edges2, hough_radii) 
centers = [] 
accums = []
radii = [] 

for radius, h in zip(hough_radii, hough_res):
 num_peaks = 10
 peaks =feature.peak_local_max(h, num_peaks=num_peaks) 
 centers.extend(peaks)
 accums.extend(h[peaks[:, 0], peaks[:, 1]])
 radii.extend([radius] * num_peaks)
big_image = color.gray2rgb(big_image/255)

big_image = transform.rotate(big_image,0)
for idx in np.argsort(accums)[::-1][:3]:
 center_x, center_y = centers[idx]
 radius = radii[idx]
 cx, cy =draw.circle_perimeter(center_y, center_x, radius)
 print(center_y,center_x,radius)
 big_image[cy,cx] = (0,255,0)

 ax1.imshow(big_image)
 ax1.set_title('detected image')
plt.show()

