from PIL import Image
import numpy as np
import cv2
import matplotlib.pyplot as plt # plt show image
import matplotlib.image as mpimg # mpimg read image
import skimage
import sys
from skimage import io 
import numpy as np
import matplotlib.pyplot as plt
from skimage import data, color,draw,transform,feature,util

image_path = 'c:/Users/xiyuq/Desktop/project/project_summer/meeting_6_25/meeting7_9_16/big_circle.png'

im2 = mpimg.imread(image_path)
plt.imshow(im2)
plt.show()
image = im2[:,:,0]

edges =feature.canny(image, sigma=1, low_threshold=10, high_threshold=50) #检测canny边缘
plt.imshow(edges)
plt.show()


 
# fig, (ax0,ax1,ax2,ax3) = plt.subplots(1,4, figsize=(18, 15))
 
# ax0.imshow(edges, cmap=plt.cm.gray) #显示canny边缘
# ax0.set_title('original iamge')
 
# hough_radii = np.arange(20, 200, 2) #半径范围

# hough_res =transform.hough_circle(edges, hough_radii) #圆变换  return len(hough_radii), width length

# centers = [] #保存中心点坐标
# accums = [] #累积值
# radii = [] #半径

# for radius, h in zip(hough_radii, hough_res):
#  #每一个半径值，取出其中9个圆
#  num_peaks = 9
#  peaks =feature.peak_local_max(h, num_peaks=num_peaks) #取出峰值
#  centers.extend(peaks)
#  accums.extend(h[peaks[:, 0], peaks[:, 1]])
#  radii.extend([radius] * num_peaks)



# # #画出最接近的5个圆
# image = color.gray2rgb(image)
# for idx in np.argsort(accums)[::-1][:1]:
#  center_x, center_y = centers[idx]
#  radius = radii[idx]
#  cx, cy =draw.circle_perimeter(center_y, center_x, radius)
#  print(center_y,center_x,radius)

#  image[cy,cx] = (250,0,0)

# ax1.imshow(image)