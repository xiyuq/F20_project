
from PIL import Image
import numpy as np
import cv2
import matplotlib.pyplot as plt # plt show image
import matplotlib.image as mpimg # mpimg read image
import skimage
import sys
from skimage import io 

# imagepath = "SAJB_90_shear_S2_02267_00553.tif"


def image2array(imagepath):
    #imagepath = "SAJB_90_shear_S2_02267_00553.tif"
    im2 = mpimg.imread(imagepath)
    
    img = Image.open(imagepath)
    R = im2[: ,: ,0]
    G = im2[: ,: ,1]
    B = im2[: ,: ,2]
    A = im2[: ,: ,3]
    # plt.imshow(lum_img,cmap = 'nipy_spectral')
    # plt.plot(736.029, 1461.87, 'ro')
    # plt.colorbar()
    return R, G, B, A, img

def plot_image(input_array):
    plt.imshow(input_array)

    #plt.plot(width/2, 1461.87, 'ro')
    #plt.colorbar()
    plt.show()

def getcoord(center, radius, width, length, num):
    theta = np.linspace(0, 2*np.pi, num)
    coord = []

    for i in theta:
        x_val = center[0]+radius*np.cos(i)
        y_val = center[1]+radius*np.sin(i)
        if x_val > 1470 or y_val > length or x_val < 0:
            continue
        temp = [int(x_val), int(y_val)]
        coord.append(temp)

    return coord

def coord2pixel(coord, img):
    coord2pixel_list = []
    count = 0
    
    for i in coord:
        coord2pixel_list.append(img.getpixel((i[0], i[1])))
    
    return sum(coord2pixel_list)

def plot_macheine_result(center, width, length, num, img):
    radius_list = np.linspace(200, 700, num)
    pixel_radius = []
    for radius in radius_list:
      coord = getcoord(center, radius, width, length, num) #many coo
      pixel_sum = coord2pixel(coord, img) / num
      pixel_radius.append(pixel_sum)

    plt.plot(radius_list, pixel_radius)
    plt.yscale('log')
    plt.xlabel('radius')
    plt.ylabel('the sum of pixel')
    plt.show()
    return 

def find_center(R, width, length):
    plt.imshow(R,cmap = 'nipy_spectral')
    print(length)
    print(width)
    plt.plot(length/2, 1462, 'ro')
    y_list = []
    for row in range(0, length-1):
        for column in range(0, width-1):
            if R[column, row] > 200 and R[column, row] < 240 and row > (500+750)/2 and row < (750 + 1000)/2 and column > 1400:
                #plt.plot(row, column, 'bo')   #check
                y_list.append(column)

    y_center = (max(y_list) + min(y_list))/2
    plt.plot(length/2, y_center, 'ro')
    plt.show()
    return length/2, y_center

def main():
    #get the message from tiff 
    imagepath = sys.argv[1]
    #num = int(sys.argv[2])
    R, G, B, A, img = image2array(imagepath)
    width = R.shape[0]
    length = R.shape[1]
    image_path = 'SAJB_90_shear_S2_02267_00553.tif'
   

    ########################################################################################
    #plot the tiff 
    plot_image(R)  #plot the tiff
    #####################################################################################
    #find the center
    #center = find_center(R, width, length)
    


    ########################################################################################
   #plot the result data
    #plot_macheine_result(center, width, length, num, img)
    ########################################################################################
    #find center



if __name__ == "__main__":
    main()
