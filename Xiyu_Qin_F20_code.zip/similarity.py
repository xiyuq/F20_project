import cv2
import numpy as np
from PIL import Image
import requests
from io import BytesIO
import matplotlib
#matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
# reference source : https://pypi.org/project/ImageHash/
 
def aHash(img):
    # average Hash
    # resize to 8*8
    img = cv2.resize(img, (8, 8))

    # reduce color
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    print(gray)

    # s is the initial value of sum pixel value
    # hash_str is the initial value of hash value
    s = 0
    hash_str = ''
    # sum of the pixel value
    for i in range(8):
        for j in range(8):
            s = s+gray[i, j]
    # average and compute the bits
    avg = s/64
    for i in range(8):
        for j in range(8):
            if gray[i, j] > avg:
                hash_str = hash_str+'1'
            else:
                hash_str = hash_str+'0'
    print(hash_str)
    return hash_str
 
def dHash(img):
    img = cv2.resize(img, (9, 8))
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    hash_str = ''
    for i in range(8):
        for j in range(8):
            if gray[i, j] > gray[i, j+1]:
                hash_str = hash_str+'1'
            else:
                hash_str = hash_str+'0'
    return hash_str
 
def pHash(img):
    img = cv2.resize(img, (32, 32))  
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    dct = cv2.dct(np.float32(gray)) # dct transformation
    dct_roi = dct[0:8, 0:8]
    hash = []
    avreage = np.mean(dct_roi)
    for i in range(dct_roi.shape[0]):
        for j in range(dct_roi.shape[1]):
            if dct_roi[i, j] > avreage:
                hash.append(1)
            else:
                hash.append(0)
    return hash
 
 
def calculate(image1, image2):
    hist1 = cv2.calcHist([image1], [0], None, [256], [0.0, 255.0])
    hist2 = cv2.calcHist([image2], [0], None, [256], [0.0, 255.0])

    degree = 0
    for i in range(len(hist1)):
        if hist1[i] != hist2[i]:
            degree = degree + \
                (1 - abs(hist1[i] - hist2[i]) / max(hist1[i], hist2[i]))
        else:
            degree = degree + 1
    degree = degree / len(hist1)
    return degree
 
 
def cmpHash(hash1, hash2):
    # compare thash
    n = 0
    if len(hash1) != len(hash2):
        return -1
    for i in range(len(hash1)):
        if hash1[i] != hash2[i]:
            n = n + 1
    return n

def runAllImageSimilaryFun(para1, para2):
    img1 = cv2.imread(para1)
    img2 = cv2.imread(para2)
  
 
    hash1 = aHash(img1)
    hash2 = aHash(img2)
    n1 = cmpHash(hash1, hash2)
    print('aHash：', n1)
 
    hash1 = dHash(img1)
    hash2 = dHash(img2)
    n2 = cmpHash(hash1, hash2)
    print('dHash：', n2)
 
    hash1 = pHash(img1)
    hash2 = pHash(img2)
    n3 = cmpHash(hash1, hash2)
    print('pHash：', n3)
 
if __name__ == "__main__":
    p1="C:/Users/xiyuq/Desktop/project/project_summer/meeting_6_25/meeting7_9_16/compare_result/left_21.png"
    p2="C:/Users/xiyuq/Desktop/project/project_summer/meeting_6_25/meeting7_9_16/compare_result/right_21.png"
    runAllImageSimilaryFun(p1,p2)