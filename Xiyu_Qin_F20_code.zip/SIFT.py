import sys
import time
import cv2
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
import imageio
import os

sift = cv2.xfeatures2d.SIFT_create()

def theta_caculation(point, mirpoint):
    x = point[0] - mirpoint[0]
    y = point[1] - mirpoint[1]
    if x == 0:
        return np.pi / 2
    else: 
        angle = np.arctan(y/x)
        if angle < 0:
            angle += np.pi
        return angle

def midpoint(point, mirpoint):
    return (point[0] + mirpoint[0]) / 2, (point[1] + mirpoint[1]) / 2

def draw(image, r, theta):
    height, width, a = np.shape(image)
    
    if np.pi / 4 < theta < 3 * (np.pi / 4):
        if theta != np.pi / 2:
            for x in range(width):
                y = int((r - x * np.cos(theta)) / np.sin(theta))
                if 0 <= y < width:
                    
                    image[y-1][x-1] = (0,255,0)
                    
                    
                    #plt.plot(x ,y, 'ro')
        else:
            for y in range(height):
                x = int((r - y * np.sin(theta)) / np.cos(theta))
                if 0 <= x < height:
                    image[y-1][x-1] = (0,255,0)
                    # plt.plot(x ,y, 'ro')
    else:
        for y in range(height):
            x = int((r - y * np.sin(theta)) / np.cos(theta))
            if 0 <= x < height:
               image[y-1][x-1] = (0,255,0)
                # plt.plot(x ,y, 'ro')

    #plt.show()

def detect(image):
    
    mimage = np.fliplr(image)
    #plt.imshow(mimage)
    #find the feature point
    kp1, des1 = sift.detectAndCompute(image, None)
    kp2, des2 = sift.detectAndCompute(mimage, None)    
    #find the match point
    bf = cv2.BFMatcher()
    matches = bf.knnMatch(des1, des2, k=2)
    houghr = np.zeros(len(matches))
    houghth = np.zeros(len(matches))
    #find mirrror pairs
    a1 = []
    a2 = []
    i = 0
    for match, match2 in matches:
        point = kp1[match.queryIdx] # test image descriptor's index
        mirpoint = kp2[match.trainIdx] # train image descriptor's index
        mirpoint2 = kp2[match2.trainIdx]

        #mirror transformation 
        #angle transformation
        mirpoint.angle = np.pi - mirpoint.angle
        if mirpoint.angle < 0:
            mirpoint.angle += 2 * np.pi

        mirpoint2.angle = np.pi - mirpoint2.angle
        if mirpoint2.angle < 0:
            mirpoint2.angle += 2 * np.pi

        #axis transformation
        mirpoint.pt = (mimage.shape[1] - mirpoint.pt[0], mirpoint.pt[1])

        # plt.plot(mirpoint.pt[0],mirpoint.pt[1], 'ro')
        # plt.plot(point.pt[0],point.pt[1], 'bo')
        # plt.imshow(image)
        #theta
        theta = theta_caculation(point.pt, mirpoint.pt)
        houghth[i] = theta
        #r
        xc, yc = midpoint(point.pt, mirpoint.pt)
        r = xc * np.cos(theta) + yc * np.sin(theta)
        houghr[i] = r
        i+=1
    
    #plt.hexbin(houghr, houghth, bins=300) # if you want to see the hough vote, you can comment out this line
    #for this project, I use similarity algorithm to define the symmetry. You can see in "similarity.py" 
    #plt.show()
    return houghr, houghth

def main():
    argc = len(sys.argv)
    image = cv2.imread(sys.argv[1])
        #cv2.imwrite('c:/Users/xiyuq/Desktop/project/project_summer/meeting_6_25/meeting7_9_16/rotate/{}'.format(i) + '.png',rotated)
    if argc == 2:
        houghr, houghth = detect(image)
        for i, j in zip(range(len(houghr)), range(len(houghth))):
            image = cv2.imread(sys.argv[1])
            plt.imshow(image)
            draw(image, houghr[i], houghth[j])
            cv2.imwrite('c:/Users/xiyuq/Desktop/project/project_summer/meeting_6_25/meeting7_9_16/similarity/hoff_{}_{}_{}'.format(i,j, houghth[j]) + '.png',image)
        
        os.chdir('c:/Users/xiyuq/Desktop/project/project_summer/meeting_6_25/meeting7_9_16/similarity')
        # for diagonal situation, we should rotate the image and compare the similarity
        for i, j in zip(range(len(houghr)), range(len(houghth))):
            
            colorImage  = Image.open('hoff_{}_{}_{}.png'.format(i,j, houghth[j]))

            rotated  = colorImage.rotate(+ (houghth[j]* 180/np.pi))
            print(type(rotated))
            rotated.save('c:/Users/xiyuq/Desktop/project/project_summer/meeting_6_25/meeting7_9_16/rotate/rotated_hoff_{}_{}_{}'.format(i,j, houghth[j]) + '.png')

if __name__ == "__main__":
    main()
